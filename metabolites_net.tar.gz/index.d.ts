declare global {
  // var WebGLUtils: any;
  // var readNetworkFile: any;
  // var getTransformForLine: any;
  // var getStrokeCorrectionForLine: any;
  // var myRequestAnimationFrame: any;
}
export {};